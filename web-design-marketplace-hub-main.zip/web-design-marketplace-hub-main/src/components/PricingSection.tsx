
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Check, X } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const PricingSection: React.FC = () => {
  const [billingPeriod, setBillingPeriod] = useState("monthly");

  const webDesignPlans = [
    {
      name: "Básico",
      monthlyPrice: 499,
      yearlyPrice: 4990,
      features: [
        "Diseño responsive",
        "Hasta 5 páginas",
        "Formulario de contacto",
        "Optimización básica SEO",
        "Integración con redes sociales"
      ],
      notIncluded: [
        "Diseño personalizado",
        "Blog/Noticias",
        "Posicionamiento SEO avanzado",
        "Área de clientes"
      ]
    },
    {
      name: "Profesional",
      monthlyPrice: 999,
      yearlyPrice: 9990,
      popular: true,
      features: [
        "Diseño responsive",
        "Hasta 10 páginas",
        "Formulario de contacto",
        "Optimización SEO intermedia",
        "Integración con redes sociales",
        "Diseño personalizado",
        "Blog/Noticias",
        "Panel de administración"
      ],
      notIncluded: [
        "Posicionamiento SEO avanzado",
        "Área de clientes"
      ]
    },
    {
      name: "Premium",
      monthlyPrice: 1999,
      yearlyPrice: 19990,
      features: [
        "Diseño responsive",
        "Páginas ilimitadas",
        "Formularios avanzados",
        "Optimización SEO avanzada",
        "Integración con redes sociales",
        "Diseño personalizado premium",
        "Blog/Noticias",
        "Panel de administración",
        "Área de clientes",
        "Integración con CRM"
      ],
      notIncluded: []
    }
  ];

  const marketingPlans = [
    {
      name: "Básico",
      monthlyPrice: 399,
      yearlyPrice: 3990,
      features: [
        "Gestión de 2 redes sociales",
        "8 publicaciones mensuales",
        "Informes mensuales",
        "Asesoramiento estratégico"
      ],
      notIncluded: [
        "Campañas publicitarias",
        "Email marketing",
        "Análisis de competencia",
        "Creación de contenido personalizado"
      ]
    },
    {
      name: "Profesional",
      monthlyPrice: 799,
      yearlyPrice: 7990,
      popular: true,
      features: [
        "Gestión de 4 redes sociales",
        "16 publicaciones mensuales",
        "Informes quincenales",
        "Asesoramiento estratégico",
        "Campañas publicitarias",
        "Email marketing básico"
      ],
      notIncluded: [
        "Análisis de competencia",
        "Creación de contenido personalizado"
      ]
    },
    {
      name: "Premium",
      monthlyPrice: 1599,
      yearlyPrice: 15990,
      features: [
        "Gestión de 6 redes sociales",
        "30 publicaciones mensuales",
        "Informes semanales",
        "Asesoramiento estratégico",
        "Campañas publicitarias",
        "Email marketing avanzado",
        "Análisis de competencia",
        "Creación de contenido personalizado"
      ],
      notIncluded: []
    }
  ];

  const seoPlans = [
    {
      name: "Básico",
      monthlyPrice: 449,
      yearlyPrice: 4490,
      features: [
        "Análisis inicial SEO",
        "Optimización on-page",
        "Informes mensuales",
        "Keywords (hasta 10)"
      ],
      notIncluded: [
        "Creación de contenido SEO",
        "Backlinks",
        "SEO local",
        "Optimización técnica avanzada"
      ]
    },
    {
      name: "Profesional",
      monthlyPrice: 899,
      yearlyPrice: 8990,
      popular: true,
      features: [
        "Análisis completo SEO",
        "Optimización on-page",
        "Informes quincenales",
        "Keywords (hasta 25)",
        "Creación de contenido SEO",
        "Backlinks básicos"
      ],
      notIncluded: [
        "SEO local",
        "Optimización técnica avanzada"
      ]
    },
    {
      name: "Premium",
      monthlyPrice: 1699,
      yearlyPrice: 16990,
      features: [
        "Análisis completo SEO",
        "Optimización on-page",
        "Informes semanales",
        "Keywords ilimitadas",
        "Creación de contenido SEO",
        "Estrategia de backlinks",
        "SEO local",
        "Optimización técnica avanzada"
      ],
      notIncluded: []
    }
  ];

  const designPlans = [
    {
      name: "Básico",
      monthlyPrice: 349,
      yearlyPrice: 3490,
      features: [
        "Logo básico",
        "Tarjetas de visita",
        "Plantilla para redes sociales",
        "1 revisión"
      ],
      notIncluded: [
        "Manual de marca",
        "Papelería corporativa",
        "Diseños publicitarios",
        "Material promocional"
      ]
    },
    {
      name: "Profesional",
      monthlyPrice: 699,
      yearlyPrice: 6990,
      popular: true,
      features: [
        "Logo profesional",
        "Tarjetas de visita",
        "Plantillas para redes sociales",
        "3 revisiones",
        "Manual de marca básico",
        "Papelería corporativa"
      ],
      notIncluded: [
        "Diseños publicitarios",
        "Material promocional"
      ]
    },
    {
      name: "Premium",
      monthlyPrice: 1299,
      yearlyPrice: 12990,
      features: [
        "Logo premium",
        "Tarjetas de visita",
        "Plantillas para redes sociales",
        "Revisiones ilimitadas",
        "Manual de marca completo",
        "Papelería corporativa",
        "Diseños publicitarios",
        "Material promocional"
      ],
      notIncluded: []
    }
  ];

  return (
    <section id="pricing" className="section-padding">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-agency-darkBlue mb-4">
            Nuestros Planes
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto mb-8">
            Selecciona el plan que mejor se adapte a las necesidades de tu negocio. Todos nuestros planes incluyen soporte técnico.
          </p>

          <div className="flex justify-center mb-8">
            <div className="bg-gray-100 p-1 rounded-lg inline-flex">
              <button
                className={`px-6 py-2 rounded-md ${
                  billingPeriod === "monthly" 
                    ? "bg-white shadow-sm text-agency-blue" 
                    : "text-gray-600"
                }`}
                onClick={() => setBillingPeriod("monthly")}
              >
                Mensual
              </button>
              <button
                className={`px-6 py-2 rounded-md ${
                  billingPeriod === "yearly" 
                    ? "bg-white shadow-sm text-agency-blue" 
                    : "text-gray-600"
                }`}
                onClick={() => setBillingPeriod("yearly")}
              >
                Anual <span className="text-xs text-agency-accent font-semibold ml-1">-15%</span>
              </button>
            </div>
          </div>
        </div>

        <Tabs defaultValue="web" className="w-full">
          <div className="flex justify-center mb-12">
            <TabsList className="bg-gray-100">
              <TabsTrigger value="web" className="px-6">Diseño Web</TabsTrigger>
              <TabsTrigger value="marketing" className="px-6">Marketing</TabsTrigger>
              <TabsTrigger value="seo" className="px-6">SEO</TabsTrigger>
              <TabsTrigger value="design" className="px-6">Diseño Gráfico</TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="web" className="mt-0">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {webDesignPlans.map((plan, index) => (
                <Card key={index} className={`overflow-hidden relative ${
                  plan.popular ? "border-agency-blue shadow-lg" : "border-gray-200"
                }`}>
                  {plan.popular && (
                    <div className="absolute top-0 right-0 bg-agency-blue text-white px-4 py-1 text-sm font-semibold">
                      Más Popular
                    </div>
                  )}
                  <CardHeader className="bg-gray-50 border-b border-gray-100">
                    <CardTitle className="text-center">
                      <h3 className="text-2xl font-bold text-agency-darkBlue">{plan.name}</h3>
                    </CardTitle>
                    <div className="text-center pt-2">
                      <span className="text-4xl font-bold text-agency-blue">
                        €{billingPeriod === "monthly" ? plan.monthlyPrice : plan.yearlyPrice}
                      </span>
                      <span className="text-gray-500">/{billingPeriod === "monthly" ? "mes" : "año"}</span>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-6">
                    <ul className="space-y-3">
                      {plan.features.map((feature, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <div className="mt-1 rounded-full bg-green-100 p-1">
                            <Check className="h-3 w-3 text-green-600" />
                          </div>
                          <span className="text-gray-700">{feature}</span>
                        </li>
                      ))}
                      {plan.notIncluded.map((feature, i) => (
                        <li key={i} className="flex items-start gap-2 text-gray-400">
                          <div className="mt-1 rounded-full bg-gray-100 p-1">
                            <X className="h-3 w-3 text-gray-400" />
                          </div>
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                  <CardFooter className="flex justify-center pb-6">
                    <Button 
                      className={`w-full ${
                        plan.popular 
                          ? "bg-agency-blue hover:bg-agency-darkBlue" 
                          : "bg-agency-blue/90 hover:bg-agency-blue"
                      } text-white button-shine`}
                    >
                      Contratar Ahora
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="marketing" className="mt-0">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {marketingPlans.map((plan, index) => (
                <Card key={index} className={`overflow-hidden relative ${
                  plan.popular ? "border-agency-blue shadow-lg" : "border-gray-200"
                }`}>
                  {plan.popular && (
                    <div className="absolute top-0 right-0 bg-agency-blue text-white px-4 py-1 text-sm font-semibold">
                      Más Popular
                    </div>
                  )}
                  <CardHeader className="bg-gray-50 border-b border-gray-100">
                    <CardTitle className="text-center">
                      <h3 className="text-2xl font-bold text-agency-darkBlue">{plan.name}</h3>
                    </CardTitle>
                    <div className="text-center pt-2">
                      <span className="text-4xl font-bold text-agency-blue">
                        €{billingPeriod === "monthly" ? plan.monthlyPrice : plan.yearlyPrice}
                      </span>
                      <span className="text-gray-500">/{billingPeriod === "monthly" ? "mes" : "año"}</span>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-6">
                    <ul className="space-y-3">
                      {plan.features.map((feature, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <div className="mt-1 rounded-full bg-green-100 p-1">
                            <Check className="h-3 w-3 text-green-600" />
                          </div>
                          <span className="text-gray-700">{feature}</span>
                        </li>
                      ))}
                      {plan.notIncluded.map((feature, i) => (
                        <li key={i} className="flex items-start gap-2 text-gray-400">
                          <div className="mt-1 rounded-full bg-gray-100 p-1">
                            <X className="h-3 w-3 text-gray-400" />
                          </div>
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                  <CardFooter className="flex justify-center pb-6">
                    <Button 
                      className={`w-full ${
                        plan.popular 
                          ? "bg-agency-blue hover:bg-agency-darkBlue" 
                          : "bg-agency-blue/90 hover:bg-agency-blue"
                      } text-white button-shine`}
                    >
                      Contratar Ahora
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="seo" className="mt-0">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {seoPlans.map((plan, index) => (
                <Card key={index} className={`overflow-hidden relative ${
                  plan.popular ? "border-agency-blue shadow-lg" : "border-gray-200"
                }`}>
                  {plan.popular && (
                    <div className="absolute top-0 right-0 bg-agency-blue text-white px-4 py-1 text-sm font-semibold">
                      Más Popular
                    </div>
                  )}
                  <CardHeader className="bg-gray-50 border-b border-gray-100">
                    <CardTitle className="text-center">
                      <h3 className="text-2xl font-bold text-agency-darkBlue">{plan.name}</h3>
                    </CardTitle>
                    <div className="text-center pt-2">
                      <span className="text-4xl font-bold text-agency-blue">
                        €{billingPeriod === "monthly" ? plan.monthlyPrice : plan.yearlyPrice}
                      </span>
                      <span className="text-gray-500">/{billingPeriod === "monthly" ? "mes" : "año"}</span>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-6">
                    <ul className="space-y-3">
                      {plan.features.map((feature, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <div className="mt-1 rounded-full bg-green-100 p-1">
                            <Check className="h-3 w-3 text-green-600" />
                          </div>
                          <span className="text-gray-700">{feature}</span>
                        </li>
                      ))}
                      {plan.notIncluded.map((feature, i) => (
                        <li key={i} className="flex items-start gap-2 text-gray-400">
                          <div className="mt-1 rounded-full bg-gray-100 p-1">
                            <X className="h-3 w-3 text-gray-400" />
                          </div>
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                  <CardFooter className="flex justify-center pb-6">
                    <Button 
                      className={`w-full ${
                        plan.popular 
                          ? "bg-agency-blue hover:bg-agency-darkBlue" 
                          : "bg-agency-blue/90 hover:bg-agency-blue"
                      } text-white button-shine`}
                    >
                      Contratar Ahora
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="design" className="mt-0">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {designPlans.map((plan, index) => (
                <Card key={index} className={`overflow-hidden relative ${
                  plan.popular ? "border-agency-blue shadow-lg" : "border-gray-200"
                }`}>
                  {plan.popular && (
                    <div className="absolute top-0 right-0 bg-agency-blue text-white px-4 py-1 text-sm font-semibold">
                      Más Popular
                    </div>
                  )}
                  <CardHeader className="bg-gray-50 border-b border-gray-100">
                    <CardTitle className="text-center">
                      <h3 className="text-2xl font-bold text-agency-darkBlue">{plan.name}</h3>
                    </CardTitle>
                    <div className="text-center pt-2">
                      <span className="text-4xl font-bold text-agency-blue">
                        €{billingPeriod === "monthly" ? plan.monthlyPrice : plan.yearlyPrice}
                      </span>
                      <span className="text-gray-500">/{billingPeriod === "monthly" ? "mes" : "año"}</span>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-6">
                    <ul className="space-y-3">
                      {plan.features.map((feature, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <div className="mt-1 rounded-full bg-green-100 p-1">
                            <Check className="h-3 w-3 text-green-600" />
                          </div>
                          <span className="text-gray-700">{feature}</span>
                        </li>
                      ))}
                      {plan.notIncluded.map((feature, i) => (
                        <li key={i} className="flex items-start gap-2 text-gray-400">
                          <div className="mt-1 rounded-full bg-gray-100 p-1">
                            <X className="h-3 w-3 text-gray-400" />
                          </div>
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                  <CardFooter className="flex justify-center pb-6">
                    <Button 
                      className={`w-full ${
                        plan.popular 
                          ? "bg-agency-blue hover:bg-agency-darkBlue" 
                          : "bg-agency-blue/90 hover:bg-agency-blue"
                      } text-white button-shine`}
                    >
                      Contratar Ahora
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        <div className="mt-16 text-center">
          <p className="text-lg text-gray-700 mb-4">¿Necesitas una solución personalizada?</p>
          <Button 
            size="lg" 
            variant="outline" 
            className="border-agency-blue text-agency-blue hover:bg-agency-blue hover:text-white"
          >
            Solicitar Presupuesto a Medida
          </Button>
        </div>
      </div>
    </section>
  );
};

export default PricingSection;
