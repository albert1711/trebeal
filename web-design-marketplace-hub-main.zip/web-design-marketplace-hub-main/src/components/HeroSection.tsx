
import React, { useEffect, useState } from 'react';
import { Button } from "@/components/ui/button";
import { ChevronRight, Laptop, Users, TrendingUp } from 'lucide-react';

interface HeroContent {
  title: string;
  subtitle: string;
  image: string;
}

const defaultContent: HeroContent = {
  title: "Llevamos tu negocio al siguiente nivel digital",
  subtitle: "Creamos soluciones digitales a medida que impulsan el crecimiento de tu negocio. Diseño web, marketing digital, SEO y diseño gráfico de calidad profesional.",
  image: "https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80"
};

const HeroSection: React.FC = () => {
  const [content, setContent] = useState<HeroContent>(defaultContent);

  useEffect(() => {
    // Load content from localStorage if available
    const savedData = localStorage.getItem('pageEditorData');
    if (savedData) {
      try {
        const data = JSON.parse(savedData);
        if (data.hero) {
          setContent({
            title: data.hero.title || defaultContent.title,
            subtitle: data.hero.subtitle || defaultContent.subtitle,
            image: data.hero.image || defaultContent.image
          });
        }
      } catch (error) {
        console.error("Error parsing saved page data:", error);
      }
    }
  }, []);

  return (
    <section id="home" className="pt-24 pb-16 md:pt-32 md:pb-24 overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-12">
          <div className="w-full lg:w-1/2 space-y-6 animate-fadeIn">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight text-agency-darkBlue">
              {content.title.includes("siguiente nivel") ? (
                <>
                  Llevamos tu negocio al <span className="text-agency-blue">siguiente nivel</span> digital
                </>
              ) : (
                content.title
              )}
            </h1>
            <p className="text-lg text-gray-600 max-w-xl">
              {content.subtitle}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button size="lg" className="bg-agency-blue hover:bg-agency-darkBlue text-white px-8 button-shine">
                Ver Servicios <ChevronRight className="ml-2 h-5 w-5" />
              </Button>
              <Button variant="outline" size="lg" className="border-agency-blue text-agency-blue hover:bg-agency-blue hover:text-white">
                Contáctanos
              </Button>
            </div>
            <div className="flex flex-wrap gap-8 pt-8">
              <div className="flex items-center gap-2">
                <div className="bg-blue-100 p-2 rounded-full">
                  <Laptop className="h-5 w-5 text-agency-blue" />
                </div>
                <div>
                  <p className="font-semibold text-gray-900">100+</p>
                  <p className="text-sm text-gray-600">Proyectos</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="bg-blue-100 p-2 rounded-full">
                  <Users className="h-5 w-5 text-agency-blue" />
                </div>
                <div>
                  <p className="font-semibold text-gray-900">50+</p>
                  <p className="text-sm text-gray-600">Clientes</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="bg-blue-100 p-2 rounded-full">
                  <TrendingUp className="h-5 w-5 text-agency-blue" />
                </div>
                <div>
                  <p className="font-semibold text-gray-900">98%</p>
                  <p className="text-sm text-gray-600">Satisfacción</p>
                </div>
              </div>
            </div>
          </div>
          <div className="w-full lg:w-1/2 relative animate-slideUp">
            <div className="relative mx-auto max-w-md">
              <div className="absolute -top-6 -left-6 w-24 h-24 bg-agency-accent rounded-lg opacity-20 animate-pulse"></div>
              <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-agency-blue rounded-lg opacity-20 animate-pulse"></div>
              <div className="relative bg-white shadow-2xl rounded-2xl overflow-hidden">
                <img 
                  src={content.image}
                  alt="Equipo digital trabajando" 
                  className="w-full h-auto"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
