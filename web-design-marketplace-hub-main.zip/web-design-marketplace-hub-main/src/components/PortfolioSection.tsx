
import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ExternalLink, Check, X } from 'lucide-react';
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger, SheetClose } from "@/components/ui/sheet";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { toast } from "@/hooks/use-toast";

const PortfolioSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState("todos");
  const [selectedProject, setSelectedProject] = useState<any>(null);
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    budget: '',
    message: '',
    services: {} as Record<string, boolean>
  });
  
  const projects = [
    {
      id: 1,
      title: "E-commerce de Moda",
      category: "web",
      image: "https://images.unsplash.com/photo-1523381294911-8d3cead13475?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80",
      description: "Tienda online con catálogo de productos, carrito de compras y pasarela de pagos integrada.",
      fullDescription: "Desarrollo completo de tienda online para marca de moda con catálogo de productos, filtros avanzados, sistema de carrito de compras, gestión de inventario y pasarela de pagos integrada. El proyecto incluyó diseño personalizado de interfaz, optimización para móviles y tablets, e integración con sistemas de logística.",
      features: ["Catálogo de productos", "Filtros avanzados", "Carrito de compras", "Pasarela de pagos", "Diseño responsive", "Panel de administración"],
      technologies: ["React", "Node.js", "MongoDB", "Stripe"]
    },
    {
      id: 2,
      title: "Campaña de Marketing B2B",
      category: "marketing",
      image: "https://images.unsplash.com/photo-1553877522-43269d4ea984?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80",
      description: "Estrategia de generación de leads para empresa de software B2B.",
      fullDescription: "Desarrollo e implementación de estrategia completa de marketing B2B para empresa de software, incluyendo generación de contenido especializado, campañas de email marketing, webinars y eventos digitales. La estrategia logró un incremento del 75% en leads cualificados.",
      features: ["Estrategia de contenidos", "Email marketing", "Webinars", "LinkedIn Ads", "Lead nurturing", "Análisis de resultados"],
      technologies: ["HubSpot", "LinkedIn Ads", "Google Analytics", "Zoom Webinars"]
    },
    {
      id: 3,
      title: "Posicionamiento SEO Abogados",
      category: "seo",
      image: "https://images.unsplash.com/photo-1589829545856-d10d557cf95f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80",
      description: "Optimización SEO para bufete de abogados, incrementando el tráfico orgánico en un 150%.",
      fullDescription: "Estrategia completa de posicionamiento SEO para bufete de abogados especializado en derecho laboral. El proyecto incluyó auditoría técnica, optimización on-page, estrategia de link building y creación de contenido especializado. Los resultados lograron un incremento del 150% en tráfico orgánico y posicionamiento en primera página para términos clave.",
      features: ["Auditoría SEO", "Optimización on-page", "Link building", "Contenido especializado", "SEO local", "Análisis de competencia"],
      technologies: ["SEMrush", "Ahrefs", "Google Search Console", "Google Analytics"]
    },
    {
      id: 4,
      title: "Rediseño de Marca Restaurante",
      category: "diseño",
      image: "https://images.unsplash.com/photo-1600880292203-757bb62b4baf?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80",
      description: "Renovación completa de la identidad visual para cadena de restaurantes.",
      fullDescription: "Rediseño completo de identidad visual para cadena de restaurantes con presencia en 3 ciudades. El proyecto incluyó nuevo logotipo, manual de marca, aplicaciones en papelería, menús, uniformes, señalética y presencia digital. El nuevo branding logró modernizar la imagen de la cadena y conectar con un público más joven.",
      features: ["Logotipo", "Manual de marca", "Papelería", "Menús", "Uniformes", "Señalética", "Redes sociales"],
      technologies: ["Adobe Illustrator", "Adobe Photoshop", "Adobe InDesign"]
    },
    {
      id: 5,
      title: "Portal Inmobiliario",
      category: "web",
      image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80",
      description: "Plataforma web con búsqueda avanzada de propiedades y área privada para agentes.",
      fullDescription: "Desarrollo de portal inmobiliario con buscador avanzado de propiedades, filtros por zona, precio y características, visualización en mapa, área privada para agentes inmobiliarios y sistema de gestión de contactos. La plataforma incluyó integración con API de tasación de propiedades.",
      features: ["Buscador avanzado", "Filtros personalizados", "Visualización en mapa", "Área privada", "Gestión de propiedades", "Gestión de contactos"],
      technologies: ["React", "Node.js", "PostgreSQL", "Google Maps API"]
    },
    {
      id: 6,
      title: "Branding Startup Tecnológica",
      category: "diseño",
      image: "https://images.unsplash.com/photo-1581291518633-83b4ebd1d83e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80",
      description: "Creación de identidad de marca completa para startup de tecnología.",
      fullDescription: "Desarrollo de identidad visual completa para startup de tecnología en el sector fintech. El proyecto incluyó naming, logotipo, paleta de colores, tipografía, sistema de iconos personalizado, guía de estilo para interfaces digitales, presentaciones corporativas y materiales para rondas de inversión.",
      features: ["Naming", "Logotipo", "Sistema visual", "Iconografía", "UI design", "Presentaciones"],
      technologies: ["Adobe Illustrator", "Figma", "Adobe Photoshop"]
    }
  ];

  const filteredProjects = activeTab === "todos" 
    ? projects 
    : projects.filter(project => project.category === activeTab);

  const servicesOptions = [
    { id: "web", label: "Diseño Web" },
    { id: "tienda", label: "Tienda Online" },
    { id: "app", label: "Aplicación Móvil" },
    { id: "seo", label: "SEO" },
    { id: "sem", label: "Google Ads" },
    { id: "social", label: "Redes Sociales" },
    { id: "email", label: "Email Marketing" },
    { id: "logo", label: "Diseño de Logo" },
    { id: "branding", label: "Branding Completo" },
    { id: "contenido", label: "Creación de Contenido" }
  ];

  const handleProjectDetails = (project: any) => {
    setSelectedProject(project);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted with data:', formData);
    setFormSubmitted(true);
    toast({
      title: "Solicitud enviada",
      description: "Nos pondremos en contacto contigo lo antes posible.",
    });
    
    setTimeout(() => {
      setFormSubmitted(false);
      setSelectedProject(null);
    }, 3000);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [id]: value
    }));
  };

  const handleSelectChange = (value: string) => {
    setFormData(prev => ({
      ...prev,
      budget: value
    }));
  };

  const handleCheckboxChange = (id: string, checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      services: {
        ...prev.services,
        [id]: checked
      }
    }));
  };

  return (
    <section id="portfolio" className="section-padding">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-agency-darkBlue mb-4">
            Nuestro Portafolio
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Conoce algunos de nuestros proyectos más destacados y los resultados que hemos obtenido para nuestros clientes.
          </p>
        </div>

        <Tabs defaultValue="todos" className="w-full" onValueChange={setActiveTab}>
          <div className="flex justify-center mb-12 overflow-x-auto">
            <TabsList className="bg-gray-100">
              <TabsTrigger value="todos" className="px-6">Todos</TabsTrigger>
              <TabsTrigger value="web" className="px-6">Diseño Web</TabsTrigger>
              <TabsTrigger value="marketing" className="px-6">Marketing</TabsTrigger>
              <TabsTrigger value="seo" className="px-6">SEO</TabsTrigger>
              <TabsTrigger value="diseño" className="px-6">Diseño Gráfico</TabsTrigger>
            </TabsList>
          </div>
          
          <TabsContent value={activeTab} className="mt-0">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredProjects.map((project) => (
                <Card key={project.id} className="overflow-hidden border-0 shadow-md hover:shadow-xl transition-shadow duration-300">
                  <div className="relative overflow-hidden h-64">
                    <img 
                      src={project.image} 
                      alt={project.title} 
                      className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                    />
                  </div>
                  <CardContent className="p-6">
                    <h3 className="text-xl font-bold text-agency-darkBlue mb-2">{project.title}</h3>
                    <p className="text-gray-600 mb-4">{project.description}</p>
                    <Sheet>
                      <SheetTrigger asChild>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="text-agency-blue border-agency-blue hover:bg-agency-blue hover:text-white"
                          onClick={() => handleProjectDetails(project)}
                        >
                          Ver Detalles <ExternalLink className="ml-2 h-4 w-4" />
                        </Button>
                      </SheetTrigger>
                      <SheetContent className="overflow-y-auto sm:max-w-md">
                        {selectedProject && (
                          <>
                            <SheetHeader>
                              <SheetTitle className="text-2xl text-agency-darkBlue">{selectedProject.title}</SheetTitle>
                              <SheetDescription>
                                Detalles del proyecto y solicitud de presupuesto personalizado
                              </SheetDescription>
                            </SheetHeader>
                            
                            <div className="mt-6">
                              <img 
                                src={selectedProject.image} 
                                alt={selectedProject.title} 
                                className="w-full h-48 object-cover rounded-md mb-4"
                              />
                              
                              <div className="space-y-4">
                                <div>
                                  <h4 className="text-lg font-semibold text-agency-darkBlue mb-2">Descripción</h4>
                                  <p className="text-gray-600">{selectedProject.fullDescription}</p>
                                </div>
                                
                                <div>
                                  <h4 className="text-lg font-semibold text-agency-darkBlue mb-2">Características</h4>
                                  <ul className="grid grid-cols-2 gap-2">
                                    {selectedProject.features.map((feature: string, idx: number) => (
                                      <li key={idx} className="flex items-center gap-2">
                                        <Check className="h-4 w-4 text-agency-blue" />
                                        <span className="text-sm text-gray-600">{feature}</span>
                                      </li>
                                    ))}
                                  </ul>
                                </div>
                                
                                <div>
                                  <h4 className="text-lg font-semibold text-agency-darkBlue mb-2">Tecnologías</h4>
                                  <div className="flex flex-wrap gap-2">
                                    {selectedProject.technologies.map((tech: string, idx: number) => (
                                      <span key={idx} className="text-xs bg-gray-100 rounded-full px-3 py-1 text-gray-600">
                                        {tech}
                                      </span>
                                    ))}
                                  </div>
                                </div>
                              </div>
                              
                              <div className="mt-8 border-t pt-6">
                                <h4 className="text-lg font-semibold text-agency-darkBlue mb-4">Solicitar presupuesto a medida</h4>
                                
                                {formSubmitted ? (
                                  <div className="bg-green-50 border border-green-200 rounded-md p-4 text-center">
                                    <Check className="h-8 w-8 text-green-500 mx-auto mb-2" />
                                    <h5 className="font-semibold text-green-700 mb-1">¡Solicitud enviada!</h5>
                                    <p className="text-green-600 text-sm">Nos pondremos en contacto contigo lo antes posible.</p>
                                  </div>
                                ) : (
                                  <form onSubmit={handleSubmit} className="space-y-4">
                                    <div className="space-y-2">
                                      <label htmlFor="name" className="text-sm font-medium text-gray-700 block">
                                        Nombre
                                      </label>
                                      <Input 
                                        id="name" 
                                        placeholder="Tu nombre" 
                                        required 
                                        value={formData.name}
                                        onChange={handleInputChange}
                                      />
                                    </div>
                                    
                                    <div className="space-y-2">
                                      <label htmlFor="email" className="text-sm font-medium text-gray-700 block">
                                        Email
                                      </label>
                                      <Input 
                                        id="email" 
                                        type="email" 
                                        placeholder="tu@email.com" 
                                        required 
                                        value={formData.email}
                                        onChange={handleInputChange}
                                      />
                                    </div>
                                    
                                    <div className="space-y-2">
                                      <label htmlFor="budget" className="text-sm font-medium text-gray-700 block">
                                        Presupuesto aproximado
                                      </label>
                                      <Select onValueChange={handleSelectChange}>
                                        <SelectTrigger>
                                          <SelectValue placeholder="Selecciona un rango" />
                                        </SelectTrigger>
                                        <SelectContent>
                                          <SelectItem value="500-1000">500€ - 1000€</SelectItem>
                                          <SelectItem value="1000-3000">1000€ - 3000€</SelectItem>
                                          <SelectItem value="3000-5000">3000€ - 5000€</SelectItem>
                                          <SelectItem value="5000+">Más de 5000€</SelectItem>
                                        </SelectContent>
                                      </Select>
                                    </div>
                                    
                                    <div className="space-y-2">
                                      <label className="text-sm font-medium text-gray-700 block mb-1">
                                        Servicios que te interesan
                                      </label>
                                      <div className="grid grid-cols-2 gap-2">
                                        {servicesOptions.map((service) => (
                                          <div key={service.id} className="flex items-center space-x-2">
                                            <Checkbox 
                                              id={service.id} 
                                              onCheckedChange={(checked) => 
                                                handleCheckboxChange(service.id, checked === true)
                                              }
                                            />
                                            <label
                                              htmlFor={service.id}
                                              className="text-sm text-gray-700 leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                                            >
                                              {service.label}
                                            </label>
                                          </div>
                                        ))}
                                      </div>
                                    </div>
                                    
                                    <div className="space-y-2">
                                      <label htmlFor="message" className="text-sm font-medium text-gray-700 block">
                                        Mensaje
                                      </label>
                                      <Textarea 
                                        id="message" 
                                        placeholder="Cuéntanos sobre tu proyecto..." 
                                        rows={4} 
                                        required 
                                        value={formData.message}
                                        onChange={handleInputChange}
                                      />
                                    </div>
                                    
                                    <Button 
                                      type="submit" 
                                      className="w-full bg-agency-blue hover:bg-agency-darkBlue"
                                    >
                                      Solicitar presupuesto
                                    </Button>
                                  </form>
                                )}
                              </div>
                            </div>
                          </>
                        )}
                      </SheetContent>
                    </Sheet>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </section>
  );
};

export default PortfolioSection;
