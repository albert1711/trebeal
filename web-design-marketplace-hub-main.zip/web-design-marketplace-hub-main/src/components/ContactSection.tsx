
import React from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Phone, Mail, MapPin, Send } from 'lucide-react';

const ContactSection: React.FC = () => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission here (would connect to backend)
    console.log("Form submitted");
  };

  const testimonials = [
    {
      text: "Trabajar con Agency Digital ha sido una experiencia increíble. Renovaron completamente nuestra presencia online y aumentaron nuestras ventas en un 40%.",
      author: "María Rodríguez",
      company: "MR Boutique",
      image: "https://randomuser.me/api/portraits/women/12.jpg"
    },
    {
      text: "El equipo de Agency Digital entendió perfectamente nuestras necesidades y creó una estrategia de marketing digital que superó todas nuestras expectativas.",
      author: "Carlos Gómez",
      company: "Restaurante El Fogón",
      image: "https://randomuser.me/api/portraits/men/32.jpg"
    },
    {
      text: "Gracias a su trabajo de SEO, ahora aparecemos en la primera página de Google para nuestras palabras clave principales. ¡Recomendado al 100%!",
      author: "Laura Martínez",
      company: "Clínica Dental Sonrisa",
      image: "https://randomuser.me/api/portraits/women/65.jpg"
    }
  ];

  return (
    <section id="contact" className="section-padding bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-agency-darkBlue mb-4">
            Contáctanos
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Estamos aquí para ayudarte. Ponte en contacto con nosotros para una consulta gratuita sobre tus proyectos digitales.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          <div>
            <div className="mb-12">
              <h3 className="text-2xl font-bold text-agency-darkBlue mb-6">
                Información de Contacto
              </h3>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="bg-agency-blue/10 p-3 rounded-full">
                    <Phone className="h-6 w-6 text-agency-blue" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Teléfono</h4>
                    <p className="text-gray-600">+34 91 123 45 67</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="bg-agency-blue/10 p-3 rounded-full">
                    <Mail className="h-6 w-6 text-agency-blue" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Email</h4>
                    <p className="text-gray-600">info@agencydigital.es</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="bg-agency-blue/10 p-3 rounded-full">
                    <MapPin className="h-6 w-6 text-agency-blue" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">Dirección</h4>
                    <p className="text-gray-600">Calle Gran Vía 123, 28013 Madrid, España</p>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-2xl font-bold text-agency-darkBlue mb-6">
                Lo Que Dicen Nuestros Clientes
              </h3>
              <div className="space-y-6">
                {testimonials.map((testimonial, index) => (
                  <Card key={index} className="p-6 border-0 shadow-md">
                    <div className="flex items-start gap-4">
                      <img 
                        src={testimonial.image} 
                        alt={testimonial.author} 
                        className="w-12 h-12 rounded-full object-cover"
                      />
                      <div>
                        <p className="text-gray-600 mb-3">"{testimonial.text}"</p>
                        <p className="font-semibold text-gray-900">{testimonial.author}</p>
                        <p className="text-sm text-agency-blue">{testimonial.company}</p>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          </div>

          <div>
            <Card className="p-6 border-0 shadow-lg">
              <h3 className="text-2xl font-bold text-agency-darkBlue mb-6">
                Envíanos un Mensaje
              </h3>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label htmlFor="name" className="text-sm font-medium text-gray-700">
                      Nombre
                    </label>
                    <Input 
                      id="name" 
                      placeholder="Tu nombre" 
                      required 
                      className="border-gray-300 focus:border-agency-blue focus:ring-agency-blue"
                    />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="email" className="text-sm font-medium text-gray-700">
                      Email
                    </label>
                    <Input 
                      id="email" 
                      type="email" 
                      placeholder="tu@email.com" 
                      required 
                      className="border-gray-300 focus:border-agency-blue focus:ring-agency-blue"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <label htmlFor="phone" className="text-sm font-medium text-gray-700">
                    Teléfono
                  </label>
                  <Input 
                    id="phone" 
                    placeholder="Tu número de teléfono" 
                    className="border-gray-300 focus:border-agency-blue focus:ring-agency-blue"
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="service" className="text-sm font-medium text-gray-700">
                    Servicio de Interés
                  </label>
                  <select 
                    id="service" 
                    className="w-full rounded-md border border-gray-300 py-2 px-3 text-gray-700 focus:border-agency-blue focus:ring-agency-blue"
                    defaultValue=""
                  >
                    <option value="" disabled>Selecciona un servicio</option>
                    <option value="web">Diseño Web</option>
                    <option value="marketing">Marketing Digital</option>
                    <option value="seo">SEO</option>
                    <option value="design">Diseño Gráfico</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label htmlFor="message" className="text-sm font-medium text-gray-700">
                    Mensaje
                  </label>
                  <Textarea 
                    id="message" 
                    placeholder="Cuéntanos sobre tu proyecto..." 
                    rows={5} 
                    required 
                    className="border-gray-300 focus:border-agency-blue focus:ring-agency-blue"
                  />
                </div>
                <Button type="submit" className="w-full bg-agency-blue hover:bg-agency-darkBlue text-white button-shine">
                  Enviar Mensaje <Send className="ml-2 h-4 w-4" />
                </Button>
              </form>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
