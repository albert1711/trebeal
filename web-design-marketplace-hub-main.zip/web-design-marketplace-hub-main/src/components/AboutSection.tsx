
import React from 'react';
import { Check, Users, Award, Clock } from 'lucide-react';

const AboutSection: React.FC = () => {
  const stats = [
    { 
      icon: <Users className="h-10 w-10 text-agency-blue" />, 
      value: '5+', 
      label: 'Años de experiencia',
      description: 'Ayudando a empresas a crecer digitalmente'
    },
    { 
      icon: <Award className="h-10 w-10 text-agency-blue" />, 
      value: '200+', 
      label: 'Proyectos entregados',
      description: 'Con clientes satisfechos en diversos sectores'
    },
    { 
      icon: <Clock className="h-10 w-10 text-agency-blue" />, 
      value: '24/7', 
      label: 'Soporte técnico',
      description: 'Estamos siempre disponibles para ayudarte'
    }
  ];

  const values = [
    {
      title: 'Calidad y Excelencia',
      description: 'Nos esforzamos por entregar trabajos de la más alta calidad que superen las expectativas de nuestros clientes.'
    },
    {
      title: 'Innovación Constante',
      description: 'Estamos al día con las últimas tendencias y tecnologías para ofrecer soluciones innovadoras.'
    },
    {
      title: 'Compromiso con Resultados',
      description: 'Nos enfocamos en generar resultados medibles que impulsen el crecimiento de tu negocio.'
    },
    {
      title: 'Atención Personalizada',
      description: 'Cada cliente recibe un servicio a medida adaptado a sus necesidades específicas.'
    }
  ];

  return (
    <section id="about" className="section-padding bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          <div className="w-full lg:w-1/2">
            <div className="relative">
              <div className="absolute -top-6 -left-6 w-24 h-24 bg-agency-accent rounded-lg opacity-20"></div>
              <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-agency-blue rounded-lg opacity-20"></div>
              <div className="relative bg-white shadow-2xl rounded-2xl overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1600880292089-90a7e086ee0c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" 
                  alt="Nuestro equipo trabajando" 
                  className="w-full h-auto"
                />
              </div>
            </div>
          </div>
          
          <div className="w-full lg:w-1/2 space-y-8">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-agency-darkBlue mb-4">
                Sobre Nosotros
              </h2>
              <p className="text-lg text-gray-600 mb-6">
                Somos un equipo de profesionales apasionados por el marketing digital y el diseño web, comprometidos con el éxito de nuestros clientes.
              </p>
              <p className="text-gray-600 mb-6">
                Desde nuestra fundación, hemos ayudado a cientos de empresas a establecer su presencia online, mejorar su visibilidad y aumentar sus ventas a través de estrategias digitales efectivas.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {stats.map((stat, index) => (
                <div key={index} className="bg-white p-6 rounded-lg shadow-md text-center">
                  <div className="flex justify-center mb-3">
                    {stat.icon}
                  </div>
                  <h3 className="text-2xl font-bold text-agency-darkBlue mb-1">{stat.value}</h3>
                  <p className="font-medium text-agency-blue mb-2">{stat.label}</p>
                  <p className="text-sm text-gray-600">{stat.description}</p>
                </div>
              ))}
            </div>
            
            <div className="space-y-4 pt-4">
              <h3 className="text-xl font-bold text-agency-darkBlue">Nuestros Valores</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {values.map((value, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <div className="mt-1">
                      <Check className="h-5 w-5 text-agency-blue" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">{value.title}</h4>
                      <p className="text-sm text-gray-600">{value.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
