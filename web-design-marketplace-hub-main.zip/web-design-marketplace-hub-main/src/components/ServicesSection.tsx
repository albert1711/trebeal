
import React from 'react';
import { Card } from "@/components/ui/card";
import { ArrowRight, Globe, TrendingUp, Search, Palette } from 'lucide-react';

const ServicesSection: React.FC = () => {
  const services = [
    {
      id: 1,
      title: 'Diseño Web',
      description: 'Creamos sitios web atractivos, rápidos y completamente personalizados que convierten visitantes en clientes.',
      icon: <Globe className="h-10 w-10 text-agency-blue" />,
      features: ['Diseño Responsive', 'Optimización de Velocidad', 'Experiencia de Usuario']
    },
    {
      id: 2,
      title: 'Marketing Digital',
      description: 'Estrategias de marketing digital efectivas para aumentar la visibilidad de tu marca y generar más ventas.',
      icon: <TrendingUp className="h-10 w-10 text-agency-blue" />,
      features: ['Redes Sociales', 'Email Marketing', 'Publicidad PPC']
    },
    {
      id: 3,
      title: 'SEO',
      description: 'Optimizamos tu sitio web para los motores de búsqueda, mejorando tu visibilidad y atrayendo tráfico orgánico.',
      icon: <Search className="h-10 w-10 text-agency-blue" />,
      features: ['SEO On-page', 'SEO Off-page', 'Análisis de Competencia']
    },
    {
      id: 4,
      title: 'Diseño Gráfico',
      description: 'Diseños visuales impactantes que comunican la esencia de tu marca y captan la atención de tu audiencia.',
      icon: <Palette className="h-10 w-10 text-agency-blue" />,
      features: ['Identidad de Marca', 'Material Publicitario', 'Contenido para Redes']
    }
  ];

  return (
    <section id="services" className="section-padding bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-agency-darkBlue mb-4">
            Nuestros Servicios
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Ofrecemos soluciones digitales completas para ayudar a tu negocio a destacar en el mundo online.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service) => (
            <Card key={service.id} className="service-card overflow-hidden border-0 shadow-md">
              <div className="p-6 flex flex-col h-full">
                <div className="mb-4">{service.icon}</div>
                <h3 className="text-xl font-bold text-agency-darkBlue mb-3">{service.title}</h3>
                <p className="text-gray-600 mb-4 flex-grow">{service.description}</p>
                <ul className="space-y-2 mb-6">
                  {service.features.map((feature, index) => (
                    <li key={index} className="flex items-center gap-2">
                      <div className="h-1.5 w-1.5 rounded-full bg-agency-blue"></div>
                      <span className="text-sm text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>
                <a href="#pricing" className="inline-flex items-center text-agency-blue font-medium hover:text-agency-darkBlue transition-colors mt-auto">
                  Ver planes <ArrowRight className="ml-2 h-4 w-4" />
                </a>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
