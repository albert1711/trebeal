
import React from "react";
import { Card, CardContent } from "@/components/ui/card";

const MessagesContent: React.FC = () => {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Mensajes Recibidos</h1>
      <Card>
        <CardContent className="pt-6">
          <p className="text-lg mb-4">Gestiona todos los mensajes y consultas recibidas a través del formulario de contacto.</p>
          <div className="bg-slate-100 p-4 rounded-md">
            <p className="text-center text-slate-500">Lista de mensajes (demo)</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default MessagesContent;
