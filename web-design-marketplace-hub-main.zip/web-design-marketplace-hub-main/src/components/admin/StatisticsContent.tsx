
import React from "react";
import { Card, CardContent } from "@/components/ui/card";

const StatisticsContent: React.FC = () => {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Estadísticas</h1>
      <Card>
        <CardContent className="pt-6">
          <p className="text-lg mb-4">Visualiza estadísticas de visitas y conversiones de tu sitio web.</p>
          <div className="bg-slate-100 p-4 rounded-md">
            <p className="text-center text-slate-500">Gráficas de estadísticas (demo)</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default StatisticsContent;
