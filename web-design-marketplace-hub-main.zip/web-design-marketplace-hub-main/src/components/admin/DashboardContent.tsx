
import React from "react";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";

const DashboardContent: React.FC = () => {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Usuarios</CardTitle>
            <CardDescription>Total de usuarios registrados</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-4xl font-bold">25</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Mensajes</CardTitle>
            <CardDescription>Mensajes recibidos</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-4xl font-bold">142</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Proyectos</CardTitle>
            <CardDescription>Proyectos completados</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-4xl font-bold">37</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default DashboardContent;
