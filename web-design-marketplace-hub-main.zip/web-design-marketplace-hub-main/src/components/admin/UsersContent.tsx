
import React from "react";
import { Card, CardContent } from "@/components/ui/card";

const UsersContent: React.FC = () => {
  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Gestión de Usuarios</h1>
      <Card>
        <CardContent className="pt-6">
          <p className="text-lg mb-4">Aquí podrás gestionar todos los usuarios registrados en el sistema.</p>
          <div className="bg-slate-100 p-4 rounded-md">
            <p className="text-center text-slate-500">Lista de usuarios (demo)</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default UsersContent;
