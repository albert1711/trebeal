
import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Define the sections that can be edited
interface EditableSectionProps {
  id: string;
  title: string;
  fields: {
    id: string;
    label: string;
    type: "text" | "textarea" | "image";
    defaultValue: string;
  }[];
}

const editableSections: EditableSectionProps[] = [
  {
    id: "hero",
    title: "Sección Principal",
    fields: [
      { id: "title", label: "Título", type: "text", defaultValue: "Llevamos tu negocio al siguiente nivel digital" },
      { id: "subtitle", label: "Subtítulo", type: "textarea", defaultValue: "Creamos soluciones digitales a medida que impulsan el crecimiento de tu negocio. Diseño web, marketing digital, SEO y diseño gráfico de calidad profesional." },
      { id: "image", label: "URL de Imagen", type: "text", defaultValue: "https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" }
    ]
  },
  {
    id: "services",
    title: "Servicios",
    fields: [
      { id: "title", label: "Título", type: "text", defaultValue: "Nuestros Servicios" },
      { id: "subtitle", label: "Subtítulo", type: "textarea", defaultValue: "Ofrecemos una amplia gama de servicios digitales para ayudar a tu negocio a crecer y destacar en línea." }
    ]
  },
  {
    id: "about",
    title: "Acerca de Nosotros",
    fields: [
      { id: "title", label: "Título", type: "text", defaultValue: "Sobre Nosotros" },
      { id: "content", label: "Contenido", type: "textarea", defaultValue: "Somos un equipo apasionado de profesionales dedicados a crear soluciones digitales excepcionales." }
    ]
  }
];

const PageEditor: React.FC = () => {
  const [activeTab, setActiveTab] = useState("hero");
  const [formData, setFormData] = useState<Record<string, Record<string, string>>>({});
  const { toast } = useToast();
  
  // Initialize form data from localStorage or default values
  useEffect(() => {
    const savedData = localStorage.getItem('pageEditorData');
    
    if (savedData) {
      setFormData(JSON.parse(savedData));
    } else {
      // Initialize with default values
      const initialData: Record<string, Record<string, string>> = {};
      
      editableSections.forEach(section => {
        initialData[section.id] = {};
        section.fields.forEach(field => {
          initialData[section.id][field.id] = field.defaultValue;
        });
      });
      
      setFormData(initialData);
      localStorage.setItem('pageEditorData', JSON.stringify(initialData));
    }
  }, []);

  const handleInputChange = (sectionId: string, fieldId: string, value: string) => {
    setFormData(prev => {
      const updatedData = {
        ...prev,
        [sectionId]: {
          ...prev[sectionId],
          [fieldId]: value
        }
      };
      return updatedData;
    });
  };

  const handleSave = () => {
    localStorage.setItem('pageEditorData', JSON.stringify(formData));
    toast({
      title: "Cambios guardados",
      description: "Los cambios han sido guardados exitosamente"
    });
  };

  const handlePreview = () => {
    // Open the main page in a new tab
    window.open('/', '_blank');
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold">Editor de Contenido</h2>
        <div className="space-x-2">
          <Button onClick={handlePreview} variant="outline">
            Previsualizar
          </Button>
          <Button onClick={handleSave}>
            Guardar Cambios
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Editor de Página Principal</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid grid-cols-3 mb-6">
              {editableSections.map(section => (
                <TabsTrigger key={section.id} value={section.id}>
                  {section.title}
                </TabsTrigger>
              ))}
            </TabsList>

            {editableSections.map(section => (
              <TabsContent key={section.id} value={section.id} className="space-y-4">
                <div className="grid gap-4">
                  {section.fields.map(field => (
                    <div key={field.id} className="space-y-2">
                      <label htmlFor={`${section.id}-${field.id}`} className="font-medium">
                        {field.label}
                      </label>
                      
                      {field.type === 'textarea' ? (
                        <Textarea
                          id={`${section.id}-${field.id}`}
                          value={formData[section.id]?.[field.id] || field.defaultValue}
                          onChange={(e) => handleInputChange(section.id, field.id, e.target.value)}
                          rows={4}
                        />
                      ) : (
                        <Input
                          id={`${section.id}-${field.id}`}
                          type="text"
                          value={formData[section.id]?.[field.id] || field.defaultValue}
                          onChange={(e) => handleInputChange(section.id, field.id, e.target.value)}
                        />
                      )}
                      
                      {/* Preview image if this is an image field */}
                      {field.type === 'image' && formData[section.id]?.[field.id] && (
                        <div className="mt-4">
                          <p className="text-sm font-medium mb-2">Vista previa:</p>
                          <img 
                            src={formData[section.id][field.id]} 
                            alt="Preview" 
                            className="max-w-full h-auto max-h-48 rounded-md border"
                          />
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default PageEditor;
