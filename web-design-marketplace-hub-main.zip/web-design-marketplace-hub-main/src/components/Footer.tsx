
import React from 'react';
import { Mail, Phone, MapPin, Facebook, Twitter, Instagram, Linkedin } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-agency-darkBlue text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          <div>
            <h3 className="text-2xl font-display font-bold text-white mb-6">
              Agency<span className="text-agency-accent">Digital</span>
            </h3>
            <p className="text-gray-300 mb-6">
              Somos tu socio para el éxito digital. Ofrecemos soluciones personalizadas de diseño web, marketing digital, SEO y diseño gráfico.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="bg-white/10 hover:bg-white/20 p-2 rounded-full transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="bg-white/10 hover:bg-white/20 p-2 rounded-full transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="bg-white/10 hover:bg-white/20 p-2 rounded-full transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="bg-white/10 hover:bg-white/20 p-2 rounded-full transition-colors">
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-6">Servicios</h4>
            <ul className="space-y-3">
              <li><a href="#services" className="text-gray-300 hover:text-white transition-colors">Diseño Web</a></li>
              <li><a href="#services" className="text-gray-300 hover:text-white transition-colors">Marketing Digital</a></li>
              <li><a href="#services" className="text-gray-300 hover:text-white transition-colors">SEO</a></li>
              <li><a href="#services" className="text-gray-300 hover:text-white transition-colors">Diseño Gráfico</a></li>
              <li><a href="#services" className="text-gray-300 hover:text-white transition-colors">Branding</a></li>
              <li><a href="#services" className="text-gray-300 hover:text-white transition-colors">Desarrollo Web</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-6">Links Rápidos</h4>
            <ul className="space-y-3">
              <li><a href="#home" className="text-gray-300 hover:text-white transition-colors">Inicio</a></li>
              <li><a href="#about" className="text-gray-300 hover:text-white transition-colors">Sobre Nosotros</a></li>
              <li><a href="#portfolio" className="text-gray-300 hover:text-white transition-colors">Portafolio</a></li>
              <li><a href="#pricing" className="text-gray-300 hover:text-white transition-colors">Precios</a></li>
              <li><a href="#contact" className="text-gray-300 hover:text-white transition-colors">Contacto</a></li>
              <li><a href="#" className="text-gray-300 hover:text-white transition-colors">Blog</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-6">Contacto</h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <Phone className="h-5 w-5 text-agency-accent mt-0.5" />
                <span className="text-gray-300">+34 91 123 45 67</span>
              </li>
              <li className="flex items-start gap-3">
                <Mail className="h-5 w-5 text-agency-accent mt-0.5" />
                <span className="text-gray-300">info@agencydigital.es</span>
              </li>
              <li className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-agency-accent mt-0.5" />
                <span className="text-gray-300">Calle Gran Vía 123, 28013 Madrid, España</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm mb-4 md:mb-0">
            © {new Date().getFullYear()} AgencyDigital. Todos los derechos reservados.
          </p>
          <div className="flex space-x-6">
            <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Política de Privacidad</a>
            <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Términos y Condiciones</a>
            <a href="#" className="text-gray-400 hover:text-white text-sm transition-colors">Cookies</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
