
import React, { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import AdminLayout from "@/components/admin/AdminLayout";
import DashboardContent from "@/components/admin/DashboardContent";
import UsersContent from "@/components/admin/UsersContent";
import MessagesContent from "@/components/admin/MessagesContent";
import PageEditor from "@/components/admin/PageEditor";
import StatisticsContent from "@/components/admin/StatisticsContent";
import SettingsContent from "@/components/admin/SettingsContent";

const Admin = () => {
  const [activeSection, setActiveSection] = useState("dashboard");

  const renderContent = () => {
    switch (activeSection) {
      case "dashboard":
        return <DashboardContent />;
      case "users":
        return <UsersContent />;
      case "messages":
        return <MessagesContent />;
      case "content":
        return <PageEditor />;
      case "stats":
        return <StatisticsContent />;
      case "settings":
        return <SettingsContent />;
      default:
        return <DashboardContent />;
    }
  };

  return (
    <AdminLayout 
      activeSection={activeSection} 
      setActiveSection={setActiveSection}
    >
      {renderContent()}
    </AdminLayout>
  );
};

export default Admin;
